#include "validation.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int validate_sequence(const int *pages, int page_count, int frame_count, char *error, size_t error_size) {
    if (page_count < 0) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Page request count cannot be negative.");
        }
        return 0;
    }
    if (frame_count <= 0) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Frame count must be greater than zero.");
        }
        return 0;
    }
    if (page_count > 10000) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Sequence is too large. Maximum 10,000 requests allowed.");
        }
        return 0;
    }
    if (frame_count > 256) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Frame count exceeds the supported range of 256 frames.");
        }
        return 0;
    }
    for (int i = 0; i < page_count; ++i) {
        if (pages[i] < 0) {
            if (error != NULL && error_size > 0) {
                snprintf(error, error_size, "Page value at index %d is negative and invalid.", i);
            }
            return 0;
        }
    }
    return 1;
}

int parse_json_int_field(const char *json, const char *field_name, int *value_out, char *error, size_t error_size) {
    if (json == NULL || field_name == NULL || value_out == NULL) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Internal parsing error.");
        }
        return 0;
    }

    char pattern[64];
    snprintf(pattern, sizeof(pattern), "\"%s\"", field_name);
    const char *field_ptr = strstr(json, pattern);
    if (field_ptr == NULL) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Missing field '%s'.", field_name);
        }
        return 0;
    }
    field_ptr = strchr(field_ptr, ':');
    if (field_ptr == NULL) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Malformed field '%s'.", field_name);
        }
        return 0;
    }

    field_ptr++;
    while (*field_ptr != '\0' && isspace((unsigned char)*field_ptr)) {
        field_ptr++;
    }

    char *end = NULL;
    long value = strtol(field_ptr, &end, 10);
    if (field_ptr == end) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Field '%s' is not a valid integer.", field_name);
        }
        return 0;
    }

    *value_out = (int)value;
    return 1;
}

int parse_json_string_field(const char *json, const char *field_name, char *value_out, size_t value_size, char *error, size_t error_size) {
    if (json == NULL || field_name == NULL || value_out == NULL || value_size == 0) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Internal parsing error.");
        }
        return 0;
    }

    char pattern[64];
    snprintf(pattern, sizeof(pattern), "\"%s\"", field_name);
    const char *field_ptr = strstr(json, pattern);
    if (field_ptr == NULL) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Missing field '%s'.", field_name);
        }
        return 0;
    }
    field_ptr = strchr(field_ptr, ':');
    if (field_ptr == NULL) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Malformed field '%s'.", field_name);
        }
        return 0;
    }
    field_ptr++;
    while (*field_ptr != '\0' && isspace((unsigned char)*field_ptr)) {
        field_ptr++;
    }
    if (*field_ptr != '"') {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Field '%s' is not a string.", field_name);
        }
        return 0;
    }

    field_ptr++;
    size_t pos = 0;
    while (*field_ptr != '\0' && *field_ptr != '"') {
        if (pos + 1 >= value_size) {
            if (error != NULL && error_size > 0) {
                snprintf(error, error_size, "Value for '%s' is too long.", field_name);
            }
            return 0;
        }
        value_out[pos++] = *field_ptr++;
    }
    value_out[pos] = '\0';
    return 1;
}

static int parse_integer_list_from_string(const char *text, int **pages_out, int *page_count_out, char *error, size_t error_size) {
    if (text == NULL) {
        return 0;
    }

    int capacity = 32;
    int *pages = (int *)malloc((size_t)capacity * sizeof(int));
    int count = 0;
    const char *scan = text;

    while (*scan != '\0') {
        while (*scan != '\0' && *scan != '-' && !isdigit((unsigned char)*scan)) {
            if (*scan == ']' || *scan == '}') {
                *pages_out = pages;
                *page_count_out = count;
                return 1;
            }
            ++scan;
        }

        if (*scan == '\0') {
            break;
        }

        char *end = NULL;
        long value = strtol(scan, &end, 10);
        if (end == scan) {
            free(pages);
            if (error != NULL && error_size > 0) {
                snprintf(error, error_size, "Malformed page value in sequence.");
            }
            return 0;
        }

        if (count >= capacity) {
            capacity *= 2;
            int *new_pages = (int *)realloc(pages, (size_t)capacity * sizeof(int));
            if (new_pages == NULL) {
                free(pages);
                if (error != NULL && error_size > 0) {
                    snprintf(error, error_size, "Memory allocation failed while parsing pages.");
                }
                return 0;
            }
            pages = new_pages;
        }

        pages[count++] = (int)value;
        scan = end;
        while (*scan != '\0' && (*scan == ' ' || *scan == '\n' || *scan == '\r' || *scan == '\t' || *scan == ',')) {
            ++scan;
        }
    }

    *pages_out = pages;
    *page_count_out = count;
    return 1;
}

int parse_pages_array(const char *json, int **pages_out, int *page_count_out, char *error, size_t error_size) {
    if (json == NULL || pages_out == NULL || page_count_out == NULL) {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Invalid request payload.");
        }
        return 0;
    }

    const char *pages_ptr = strstr(json, "\"pages\"");
    if (pages_ptr != NULL) {
        pages_ptr = strchr(pages_ptr, '[');
        if (pages_ptr == NULL) {
            if (error != NULL && error_size > 0) {
                snprintf(error, error_size, "Malformed 'pages' array.");
            }
            return 0;
        }
        if (!parse_integer_list_from_string(pages_ptr, pages_out, page_count_out, error, error_size)) {
            return 0;
        }
        return 1;
    }

    const char *sequence_ptr = strstr(json, "\"sequence\"");
    if (sequence_ptr != NULL) {
        sequence_ptr = strchr(sequence_ptr, ':');
        if (sequence_ptr == NULL) {
            if (error != NULL && error_size > 0) {
                snprintf(error, error_size, "Malformed 'sequence' field.");
            }
            return 0;
        }
        sequence_ptr++;
        while (*sequence_ptr != '\0' && (*sequence_ptr == ' ' || *sequence_ptr == '\n' || *sequence_ptr == '\r' || *sequence_ptr == '\t')) {
            ++sequence_ptr;
        }

        if (*sequence_ptr == '"') {
            const char *value_start = sequence_ptr + 1;
            const char *value_end = value_start;
            while (*value_end != '\0' && *value_end != '"') {
                ++value_end;
            }
            if (*value_end != '"') {
                if (error != NULL && error_size > 0) {
                    snprintf(error, error_size, "Unterminated sequence value.");
                }
                return 0;
            }

            char sequence_value[4096];
            size_t len = (size_t)(value_end - value_start);
            if (len >= sizeof(sequence_value)) {
                if (error != NULL && error_size > 0) {
                    snprintf(error, error_size, "Sequence is too long.");
                }
                return 0;
            }
            memcpy(sequence_value, value_start, len);
            sequence_value[len] = '\0';
            return parse_integer_list_from_string(sequence_value, pages_out, page_count_out, error, error_size);
        }

        if (*sequence_ptr == '[') {
            return parse_integer_list_from_string(sequence_ptr, pages_out, page_count_out, error, error_size);
        }
    }

    if (error != NULL && error_size > 0) {
        snprintf(error, error_size, "Missing 'pages' array or 'sequence' field.");
    }
    return 0;
}

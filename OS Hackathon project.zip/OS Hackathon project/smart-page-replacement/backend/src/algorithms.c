#include "algorithms.h"

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int next_occurrence_index(const int *pages, int page_count, int target_page, int start_index) {
    for (int i = start_index; i < page_count; ++i) {
        if (pages[i] == target_page) {
            return i;
        }
    }
    return -1;
}

const char *algorithm_name_string(AlgorithmType algorithm) {
    switch (algorithm) {
        case ALGO_FIFO:
            return "FIFO";
        case ALGO_LRU:
            return "LRU";
        case ALGO_OPTIMAL:
            return "Optimal";
        default:
            return "Unknown";
    }
}

static void copy_current_frames(SimulationStep *step, const int *frames, int frame_count) {
    step->frame_count = frame_count;
    step->frames = (int *)calloc((size_t)frame_count, sizeof(int));
    if (step->frames != NULL) {
        for (int i = 0; i < frame_count; ++i) {
            step->frames[i] = frames[i];
        }
    }
}

static void fill_empty_frames(int *frames, int frame_count) {
    for (int i = 0; i < frame_count; ++i) {
        frames[i] = -1;
    }
}

static int find_page_slot(const int *frames, int frame_count, int page) {
    for (int i = 0; i < frame_count; ++i) {
        if (frames[i] == page) {
            return i;
        }
    }
    return -1;
}

int validate_algorithm_name(const char *value, AlgorithmType *algorithm, char *error, size_t error_size) {
    if (value == NULL || value[0] == '\0') {
        if (error != NULL && error_size > 0) {
            snprintf(error, error_size, "Algorithm name is required.");
        }
        return 0;
    }

    if (strcmp(value, "FIFO") == 0 || strcmp(value, "fifo") == 0) {
        *algorithm = ALGO_FIFO;
        return 1;
    }
    if (strcmp(value, "LRU") == 0 || strcmp(value, "lru") == 0) {
        *algorithm = ALGO_LRU;
        return 1;
    }
    if (strcmp(value, "Optimal") == 0 || strcmp(value, "optimal") == 0 || strcmp(value, "OPTIMAL") == 0) {
        *algorithm = ALGO_OPTIMAL;
        return 1;
    }

    if (error != NULL && error_size > 0) {
        snprintf(error, error_size, "Invalid algorithm '%s'. Supported: FIFO, LRU, Optimal.", value);
    }
    return 0;
}

int simulate_pages(const int *pages, int page_count, int frame_count, AlgorithmType algorithm, SimulationResult *result) {
    if (result == NULL) {
        return 0;
    }

    memset(result, 0, sizeof(*result));
    result->algorithm = algorithm;
    snprintf(result->algorithm_name, sizeof(result->algorithm_name), "%s", algorithm_name_string(algorithm));
    result->total_requests = page_count;
    result->frame_count = frame_count;

    if (pages == NULL || page_count < 0 || frame_count <= 0 || algorithm < ALGO_FIFO || algorithm > ALGO_OPTIMAL) {
        result->step_count = 0;
        result->steps = NULL;
        return 0;
    }

    if (page_count == 0) {
        result->step_count = 0;
        result->steps = NULL;
        result->hit_rate = 0.0;
        result->fault_rate = 0.0;
        return 1;
    }

    result->steps = (SimulationStep *)calloc((size_t)page_count, sizeof(SimulationStep));
    if (result->steps == NULL) {
        return 0;
    }

    int *frames = (int *)calloc((size_t)frame_count, sizeof(int));
    int *fifo_order = (int *)calloc((size_t)frame_count, sizeof(int));
    int *last_used = (int *)calloc((size_t)frame_count, sizeof(int));
    int *fifo_stamp = (int *)calloc((size_t)frame_count, sizeof(int));

    if (frames == NULL || fifo_order == NULL || last_used == NULL || fifo_stamp == NULL) {
        free(frames);
        free(fifo_order);
        free(last_used);
        free(fifo_stamp);
        free_simulation_result(result);
        return 0;
    }

    fill_empty_frames(frames, frame_count);
    int active_frames = 0;
    int clock_tick = 0;

    for (int i = 0; i < page_count; ++i) {
        SimulationStep *step = &result->steps[i];
        const int page = pages[i];
        step->step_number = i + 1;
        step->request_index = i;
        step->requested_page = page;
        step->frame_count = frame_count;
        step->frames = NULL;
        step->replaced_page = -1;
        step->replaced_index = -1;
        step->hit = 0;
        step->page_fault = 0;

        int existing_index = find_page_slot(frames, frame_count, page);
        if (existing_index >= 0) {
            step->hit = 1;
            result->page_hits += 1;
            if (algorithm == ALGO_LRU) {
                last_used[existing_index] = ++clock_tick;
            } else if (algorithm == ALGO_FIFO) {
                fifo_stamp[existing_index] = ++clock_tick;
            }
            snprintf(step->reason, sizeof(step->reason), "Page %d is already in memory; it is a hit.", page);
            copy_current_frames(step, frames, frame_count);
            continue;
        }

        result->page_faults += 1;
        step->page_fault = 1;

        if (active_frames < frame_count) {
            int index = active_frames;
            frames[index] = page;
            fifo_order[index] = page;
            fifo_stamp[index] = ++clock_tick;
            last_used[index] = clock_tick;
            active_frames += 1;
            snprintf(step->reason, sizeof(step->reason), "Page %d was loaded into an empty frame.", page);
        } else {
            int evict_index = 0;
            int evicted_page = -1;

            if (algorithm == ALGO_FIFO) {
                int oldest_stamp = INT_MAX;
                for (int j = 0; j < frame_count; ++j) {
                    if (fifo_stamp[j] < oldest_stamp) {
                        oldest_stamp = fifo_stamp[j];
                        evict_index = j;
                    }
                }
                evicted_page = frames[evict_index];
                snprintf(step->reason, sizeof(step->reason), "FIFO evicted page %d because it entered memory first.", evicted_page);
            } else if (algorithm == ALGO_LRU) {
                int least_recent = INT_MAX;
                for (int j = 0; j < frame_count; ++j) {
                    if (last_used[j] < least_recent) {
                        least_recent = last_used[j];
                        evict_index = j;
                    }
                }
                evicted_page = frames[evict_index];
                snprintf(step->reason, sizeof(step->reason), "LRU evicted page %d because it was least recently used.", evicted_page);
            } else {
                int best_distance = INT_MIN;
                for (int j = 0; j < frame_count; ++j) {
                    int future_index = next_occurrence_index(pages, page_count, frames[j], i + 1);
                    int distance = (future_index == -1) ? INT_MAX : future_index - (i + 1);
                    if (distance > best_distance) {
                        best_distance = distance;
                        evict_index = j;
                    }
                }
                evicted_page = frames[evict_index];
                snprintf(step->reason, sizeof(step->reason), "Optimal evicted page %d because it is used farthest in the future.", evicted_page);
            }

            step->replaced_page = evicted_page;
            step->replaced_index = evict_index;
            frames[evict_index] = page;
            fifo_stamp[evict_index] = ++clock_tick;
            last_used[evict_index] = clock_tick;
            result->evictions += 1;
        }

        copy_current_frames(step, frames, frame_count);
    }

    result->step_count = page_count;
    result->hit_rate = (page_count == 0) ? 0.0 : ((double)result->page_hits / (double)page_count) * 100.0;
    result->fault_rate = (page_count == 0) ? 0.0 : ((double)result->page_faults / (double)page_count) * 100.0;

    free(frames);
    free(fifo_order);
    free(last_used);
    free(fifo_stamp);
    return 1;
}

void free_simulation_result(SimulationResult *result) {
    if (result == NULL) {
        return;
    }

    if (result->steps != NULL) {
        for (int i = 0; i < result->step_count; ++i) {
            free(result->steps[i].frames);
        }
        free(result->steps);
        result->steps = NULL;
    }

    result->step_count = 0;
}

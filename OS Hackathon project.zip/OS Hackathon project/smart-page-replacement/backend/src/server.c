#include "server.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#ifdef _MSC_VER
#pragma comment(lib, "ws2_32.lib")
#endif
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#endif

#include "algorithms.h"
#include "json_utils.h"
#include "validation.h"

#define REQUEST_BUFFER_SIZE 65536
static long server_start_time = 0;

static const char *content_type_for_path(const char *path) {
    const char *ext = strrchr(path, '.');
    if (ext == NULL) {
        return "text/plain";
    }
    if (strcmp(ext, ".html") == 0) {
        return "text/html";
    }
    if (strcmp(ext, ".css") == 0) {
        return "text/css";
    }
    if (strcmp(ext, ".js") == 0) {
        return "application/javascript";
    }
    if (strcmp(ext, ".png") == 0) {
        return "image/png";
    }
    if (strcmp(ext, ".jpg") == 0 || strcmp(ext, ".jpeg") == 0) {
        return "image/jpeg";
    }
    if (strcmp(ext, ".svg") == 0) {
        return "image/svg+xml";
    }
    return "application/octet-stream";
}

static int file_exists(const char *path) {
    FILE *fp = fopen(path, "rb");
    if (fp == NULL) {
        return 0;
    }
    fclose(fp);
    return 1;
}

static int send_http_response(int client_socket, const char *status, const char *content_type, const char *body, size_t body_length) {
    char header[1024];
    snprintf(header, sizeof(header),
        "HTTP/1.1 %s\r\nContent-Type: %s\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
        status,
        content_type,
        body_length);
    send(client_socket, header, strlen(header), 0);
    if (body != NULL && body_length > 0) {
        send(client_socket, body, body_length, 0);
    }
    return 1;
}

static int send_text_response(int client_socket, int status_code, const char *status_text, const char *content_type, const char *payload) {
    size_t len = payload == NULL ? 0 : strlen(payload);
    char status_line[64];
    snprintf(status_line, sizeof(status_line), "%d %s", status_code, status_text);
    return send_http_response(client_socket, status_line, content_type, payload, len);
}

static int serve_static_file(int client_socket, const char *frontend_root, const char *request_path) {
    char file_path[SERVER_MAX_PATH];
    if (strcmp(request_path, "/") == 0) {
        snprintf(file_path, sizeof(file_path), "%s/index.html", frontend_root);
    } else {
        snprintf(file_path, sizeof(file_path), "%s%s", frontend_root, request_path);
    }

    if (!file_exists(file_path)) {
        return 0;
    }

    FILE *file = fopen(file_path, "rb");
    if (file == NULL) {
        return 0;
    }
    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);
    unsigned char *data = (unsigned char *)malloc((size_t)size + 1);
    if (data == NULL) {
        fclose(file);
        return 0;
    }
    size_t bytes_read = fread(data, 1, (size_t)size, file);
    fclose(file);
    data[bytes_read] = '\0';

    char header[1024];
    snprintf(header, sizeof(header),
        "HTTP/1.1 200 OK\r\nContent-Type: %s\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
        content_type_for_path(file_path),
        bytes_read);
    send(client_socket, header, strlen(header), 0);
    send(client_socket, (const char *)data, bytes_read, 0);
    free(data);
    return 1;
}

static int should_serve_static_file(const char *path) {
    return strcmp(path, "/") == 0 ||
           strcmp(path, "/index.html") == 0 ||
           strncmp(path, "/css/", 5) == 0 ||
           strncmp(path, "/js/", 4) == 0 ||
           strncmp(path, "/assets/", 8) == 0;
}

static int handle_compare_api(int client_socket, const char *body, const char *version) {
    int *pages = NULL;
    int page_count = 0;
    int frames = 0;
    char error[256];

    if (!parse_pages_array(body, &pages, &page_count, error, sizeof(error))) {
        char payload[512];
        snprintf(payload, sizeof(payload), "{\"error\":\"%s\"}", error);
        send_text_response(client_socket, 400, "Bad Request", "application/json", payload);
        free(pages);
        return 1;
    }
    if (!parse_json_int_field(body, "frames", &frames, error, sizeof(error))) {
        char payload[512];
        snprintf(payload, sizeof(payload), "{\"error\":\"%s\"}", error);
        send_text_response(client_socket, 400, "Bad Request", "application/json", payload);
        free(pages);
        return 1;
    }
    if (!validate_sequence(pages, page_count, frames, error, sizeof(error))) {
        char payload[512];
        snprintf(payload, sizeof(payload), "{\"error\":\"%s\"}", error);
        send_text_response(client_socket, 400, "Bad Request", "application/json", payload);
        free(pages);
        return 1;
    }

    SimulationResult results[3];
    AlgorithmType algorithms[3] = {ALGO_FIFO, ALGO_LRU, ALGO_OPTIMAL};
    for (int i = 0; i < 3; ++i) {
        if (!simulate_pages(pages, page_count, frames, algorithms[i], &results[i])) {
            char payload[256];
            snprintf(payload, sizeof(payload), "{\"error\":\"Simulation failed for %s.\"}", algorithm_name_string(algorithms[i]));
            send_text_response(client_socket, 500, "Internal Server Error", "application/json", payload);
            free(pages);
            return 1;
        }
    }

    char payload[32768];
    write_compare_json(payload, sizeof(payload), results, 3, version);
    send_text_response(client_socket, 200, "OK", "application/json", payload);
    free(pages);
    for (int i = 0; i < 3; ++i) {
        free_simulation_result(&results[i]);
    }
    return 1;
}

static int handle_simulate_api(int client_socket, const char *body, const char *version) {
    int *pages = NULL;
    int page_count = 0;
    int frames = 0;
    char algorithm_name[32];
    char error[256];

    if (!parse_pages_array(body, &pages, &page_count, error, sizeof(error))) {
        char payload[512];
        snprintf(payload, sizeof(payload), "{\"error\":\"%s\"}", error);
        send_text_response(client_socket, 400, "Bad Request", "application/json", payload);
        free(pages);
        return 1;
    }
    if (!parse_json_int_field(body, "frames", &frames, error, sizeof(error))) {
        char payload[512];
        snprintf(payload, sizeof(payload), "{\"error\":\"%s\"}", error);
        send_text_response(client_socket, 400, "Bad Request", "application/json", payload);
        free(pages);
        return 1;
    }
    if (!parse_json_string_field(body, "algorithm", algorithm_name, sizeof(algorithm_name), error, sizeof(error))) {
        char payload[512];
        snprintf(payload, sizeof(payload), "{\"error\":\"%s\"}", error);
        send_text_response(client_socket, 400, "Bad Request", "application/json", payload);
        free(pages);
        return 1;
    }
    if (!validate_sequence(pages, page_count, frames, error, sizeof(error))) {
        char payload[512];
        snprintf(payload, sizeof(payload), "{\"error\":\"%s\"}", error);
        send_text_response(client_socket, 400, "Bad Request", "application/json", payload);
        free(pages);
        return 1;
    }

    AlgorithmType algorithm = ALGO_INVALID;
    if (!validate_algorithm_name(algorithm_name, &algorithm, error, sizeof(error))) {
        char payload[512];
        snprintf(payload, sizeof(payload), "{\"error\":\"%s\"}", error);
        send_text_response(client_socket, 400, "Bad Request", "application/json", payload);
        free(pages);
        return 1;
    }

    SimulationResult result;
    if (!simulate_pages(pages, page_count, frames, algorithm, &result)) {
        char payload[256];
        snprintf(payload, sizeof(payload), "{\"error\":\"Simulation failed for %s.\"}", algorithm_name);
        send_text_response(client_socket, 500, "Internal Server Error", "application/json", payload);
        free(pages);
        return 1;
    }

    char payload[32768];
    write_simulation_json(payload, sizeof(payload), &result, version);
    send_text_response(client_socket, 200, "OK", "application/json", payload);
    free(pages);
    free_simulation_result(&result);
    return 1;
}

static void handle_api_request(int client_socket, const char *method, const char *path, const char *body, const char *version, const char *frontend_root) {
    if (strcmp(method, "GET") == 0 && strcmp(path, "/api/health") == 0) {
        char payload[512];
        write_health_json(payload, sizeof(payload), 200, version, time(NULL) - server_start_time);
        send_text_response(client_socket, 200, "OK", "application/json", payload);
        return;
    }
    if (strcmp(method, "GET") == 0 && strcmp(path, "/api/algorithms") == 0) {
        char payload[4096];
        write_algorithm_list_json(payload, sizeof(payload), version);
        send_text_response(client_socket, 200, "OK", "application/json", payload);
        return;
    }
    if (strcmp(method, "GET") == 0 && strcmp(path, "/api/example") == 0) {
        char payload[512];
        write_example_json(payload, sizeof(payload), version);
        send_text_response(client_socket, 200, "OK", "application/json", payload);
        return;
    }
    if (strcmp(method, "POST") == 0 && strcmp(path, "/api/simulate") == 0) {
        handle_simulate_api(client_socket, body, version);
        return;
    }
    if (strcmp(method, "POST") == 0 && strcmp(path, "/api/compare") == 0) {
        handle_compare_api(client_socket, body, version);
        return;
    }
    if (strcmp(method, "GET") == 0 && should_serve_static_file(path)) {
        if (!serve_static_file(client_socket, frontend_root, path)) {
            char payload[256];
            snprintf(payload, sizeof(payload), "{\"error\":\"File not found.\"}");
            send_text_response(client_socket, 404, "Not Found", "application/json", payload);
        }
        return;
    }

    char payload[256];
    snprintf(payload, sizeof(payload), "{\"error\":\"Endpoint not found.\"}");
    send_text_response(client_socket, 404, "Not Found", "application/json", payload);
}

static int handle_connection(int client_socket, const char *frontend_root) {
    char request[REQUEST_BUFFER_SIZE];
    size_t total_received = 0;
    int headers_complete = 0;

    while (total_received < sizeof(request) - 1) {
        int received = recv(client_socket, request + total_received, sizeof(request) - 1 - total_received, 0);
        if (received <= 0) {
            break;
        }
        total_received += (size_t)received;
        request[total_received] = '\0';

        if (strstr(request, "\r\n\r\n") != NULL || strstr(request, "\n\n") != NULL) {
            headers_complete = 1;
            break;
        }
    }
    if (total_received == 0 || !headers_complete) {
        closesocket(client_socket);
        return 0;
    }

    char *body = "";
    size_t content_length = 0;
    char *body_marker = strstr(request, "\r\n\r\n");
    if (body_marker == NULL) {
        body_marker = strstr(request, "\n\n");
    }
    if (body_marker != NULL) {
        body = body_marker + (body_marker[0] == '\r' ? 4 : 2);
    }

    char *content_length_header = strstr(request, "Content-Length:");
    if (content_length_header != NULL) {
        char *value = content_length_header + strlen("Content-Length:");
        content_length = (size_t)strtoul(value, NULL, 10);
    }

    if (content_length > 0) {
        size_t body_start_offset = (size_t)(body - request);
        size_t body_bytes = total_received - body_start_offset;
        while (body_bytes < content_length && total_received < sizeof(request) - 1) {
            int received = recv(client_socket, request + total_received, sizeof(request) - 1 - total_received, 0);
            if (received <= 0) {
                break;
            }
            total_received += (size_t)received;
            request[total_received] = '\0';
            body_bytes = total_received - body_start_offset;
        }
        if (body != NULL) {
            body[content_length] = '\0';
        }
    }

    fprintf(stderr, "REQUEST_RAW=%s\n", request);

    char request_line_copy[REQUEST_BUFFER_SIZE];
    snprintf(request_line_copy, sizeof(request_line_copy), "%s", request);
    char *request_line = request_line_copy;
    char *line_end = strstr(request_line, "\r\n");
    if (line_end != NULL) {
        *line_end = '\0';
    }

    char *method = strtok(request_line, " \t");
    char *path = strtok(NULL, " \t");
    char *protocol = strtok(NULL, " \t");
    if (method == NULL || path == NULL || protocol == NULL) {
        closesocket(client_socket);
        return 0;
    }

    char version[32] = "1.0.0";
    handle_api_request(client_socket, method, path, body, version, frontend_root);
    closesocket(client_socket);
    return 1;
}

int start_server(const ServerConfig *config) {
    if (config == NULL) {
        return 0;
    }

    server_start_time = time(NULL);

#ifdef _WIN32
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        return 0;
    }
#endif

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        return 0;
    }

    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (const char *)&opt, sizeof(opt));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(config->port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    if (bind(server_fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        fprintf(stderr, "Failed to bind to localhost:%d.\n", config->port);
        closesocket(server_fd);
        return 0;
    }

    if (listen(server_fd, 10) != 0) {
        fprintf(stderr, "Failed to listen on localhost:%d.\n", config->port);
        closesocket(server_fd);
        return 0;
    }

    printf("Smart Page Replacement Simulator running on http://localhost:%d\n", config->port);
    fflush(stdout);

    while (1) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        int client_socket = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_socket < 0) {
            continue;
        }
        handle_connection(client_socket, config->frontend_root);
    }

    closesocket(server_fd);
    return 1;
}

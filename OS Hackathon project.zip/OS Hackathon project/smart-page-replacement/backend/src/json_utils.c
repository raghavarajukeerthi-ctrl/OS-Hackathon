#include "json_utils.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void json_escape_string(char *dst, size_t dst_size, const char *src) {
    if (dst == NULL || dst_size == 0 || src == NULL) {
        return;
    }

    size_t pos = 0;
    for (size_t i = 0; src[i] != '\0' && pos + 1 < dst_size; ++i) {
        char ch = src[i];
        switch (ch) {
            case '\\':
                if (pos + 2 < dst_size) {
                    dst[pos++] = '\\';
                    dst[pos++] = '\\';
                }
                break;
            case '"':
                if (pos + 2 < dst_size) {
                    dst[pos++] = '\\';
                    dst[pos++] = '"';
                }
                break;
            case '\n':
                if (pos + 2 < dst_size) {
                    dst[pos++] = '\\';
                    dst[pos++] = 'n';
                }
                break;
            case '\r':
                if (pos + 2 < dst_size) {
                    dst[pos++] = '\\';
                    dst[pos++] = 'r';
                }
                break;
            case '\t':
                if (pos + 2 < dst_size) {
                    dst[pos++] = '\\';
                    dst[pos++] = 't';
                }
                break;
            default:
                dst[pos++] = ch;
                break;
        }
    }
    dst[pos] = '\0';
}

int write_health_json(char *buffer, size_t buffer_size, int status_code, const char *version, long uptime_seconds) {
    if (buffer == NULL || buffer_size == 0) {
        return 0;
    }
    snprintf(buffer, buffer_size,
        "{\"status\":\"ok\",\"version\":\"%s\",\"status_code\":%d,\"uptime_seconds\":%ld}",
        version ? version : "1.0.0", status_code, uptime_seconds);
    return 1;
}

int write_algorithm_list_json(char *buffer, size_t buffer_size, const char *version) {
    if (buffer == NULL || buffer_size == 0) {
        return 0;
    }
    snprintf(buffer, buffer_size,
        "{\"version\":\"%s\",\"algorithms\":[{\"name\":\"FIFO\",\"description\":\"First In, First Out\",\"time_complexity\":\"O(n * f)\",\"space_complexity\":\"O(f)\"},{\"name\":\"LRU\",\"description\":\"Least Recently Used\",\"time_complexity\":\"O(n * f)\",\"space_complexity\":\"O(f)\"},{\"name\":\"Optimal\",\"description\":\"Offline benchmark\",\"time_complexity\":\"O(n * f * p)\",\"space_complexity\":\"O(f)\"}]}",
        version ? version : "1.0.0");
    return 1;
}

int write_example_json(char *buffer, size_t buffer_size, const char *version) {
    if (buffer == NULL || buffer_size == 0) {
        return 0;
    }
    snprintf(buffer, buffer_size,
        "{\"version\":\"%s\",\"example\":{\"sequence\":\"7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2\",\"pages\":[7,0,1,2,0,3,0,4,2,3,0,3,2],\"frames\":3,\"algorithm\":\"LRU\"}}",
        version ? version : "1.0.0");
    return 1;
}

int write_simulation_json(char *buffer, size_t buffer_size, const SimulationResult *result, const char *version) {
    if (buffer == NULL || buffer_size == 0 || result == NULL) {
        return 0;
    }

    size_t offset = 0;
    snprintf(buffer, buffer_size,
        "{\"version\":\"%s\",\"algorithm\":\"%s\",\"hits\":%d,\"faults\":%d,\"total_requests\":%d,\"page_hits\":%d,\"page_faults\":%d,\"evictions\":%d,\"hit_rate\":%.2f,\"fault_rate\":%.2f,\"frame_count\":%d,\"steps\":[",
        version ? version : "1.0.0",
        result->algorithm_name,
        result->page_hits,
        result->page_faults,
        result->total_requests,
        result->page_hits,
        result->page_faults,
        result->evictions,
        result->hit_rate,
        result->fault_rate,
        result->frame_count);
    offset = strlen(buffer);

    for (int i = 0; i < result->step_count; ++i) {
        const SimulationStep *step = &result->steps[i];
        char safe_reason[MAX_REASON_CHARS];
        json_escape_string(safe_reason, sizeof(safe_reason), step->reason);
        char temp[2000];
        snprintf(temp, sizeof(temp),
            "%s{\"step_number\":%d,\"request_index\":%d,\"requested_page\":%d,\"hit\":%s,\"page_fault\":%s,\"replaced_page\":%d,\"replaced_index\":%d,\"frames\":[",
            (i == 0) ? "" : ",",
            step->step_number,
            step->request_index,
            step->requested_page,
            step->hit ? "true" : "false",
            step->page_fault ? "true" : "false",
            step->replaced_page >= 0 ? step->replaced_page : -1,
            step->replaced_index >= 0 ? step->replaced_index : -1);
        if (offset + strlen(temp) + 1 >= buffer_size) {
            break;
        }
        memcpy(buffer + offset, temp, strlen(temp));
        offset += strlen(temp);
        if (step->frames != NULL) {
            for (int j = 0; j < step->frame_count; ++j) {
                char frame_temp[32];
                snprintf(frame_temp, sizeof(frame_temp), "%s%d", (j == 0) ? "" : ",", step->frames[j]);
                if (offset + strlen(frame_temp) + 1 >= buffer_size) {
                    break;
                }
                memcpy(buffer + offset, frame_temp, strlen(frame_temp));
                offset += strlen(frame_temp);
            }
        }
        snprintf(temp, sizeof(temp), "],\"reason\":\"%s\"}", safe_reason);
        if (offset + strlen(temp) + 1 >= buffer_size) {
            break;
        }
        memcpy(buffer + offset, temp, strlen(temp));
        offset += strlen(temp);
    }

    snprintf(buffer + offset, buffer_size - offset, "]}");
    return 1;
}

int write_compare_json(char *buffer, size_t buffer_size, const SimulationResult *results, int count, const char *version) {
    if (buffer == NULL || buffer_size == 0 || results == NULL || count <= 0) {
        return 0;
    }

    size_t offset = 0;
    snprintf(buffer, buffer_size, "{\"version\":\"%s\",\"results\":[", version ? version : "1.0.0");
    offset = strlen(buffer);

    for (int i = 0; i < count; ++i) {
        char item[1024];
        snprintf(item, sizeof(item),
            "%s{\"algorithm\":\"%s\",\"hits\":%d,\"faults\":%d,\"total_requests\":%d,\"page_hits\":%d,\"page_faults\":%d,\"hit_rate\":%.2f,\"fault_rate\":%.2f,\"evictions\":%d}",
            (i == 0) ? "" : ",",
            results[i].algorithm_name,
            results[i].page_hits,
            results[i].page_faults,
            results[i].total_requests,
            results[i].page_hits,
            results[i].page_faults,
            results[i].hit_rate,
            results[i].fault_rate,
            results[i].evictions);
        if (offset + strlen(item) + 1 >= buffer_size) {
            break;
        }
        memcpy(buffer + offset, item, strlen(item));
        offset += strlen(item);
    }

    const char *winner = results[0].algorithm_name;
    int min_faults = results[0].page_faults;
    for (int i = 1; i < count; ++i) {
        if (results[i].page_faults < min_faults) {
            min_faults = results[i].page_faults;
            winner = results[i].algorithm_name;
        }
    }
    snprintf(buffer + offset, buffer_size - offset, "],\"winner\":\"%s\"}", winner);
    return 1;
}

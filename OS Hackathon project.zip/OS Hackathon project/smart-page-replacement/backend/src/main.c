#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "server.h"

static void print_usage(const char *program_name) {
    printf("Usage: %s [--port <number>] [--frontend-root <path>]\n", program_name);
    printf("Default port: %d\n", SERVER_DEFAULT_PORT);
}

int main(int argc, char **argv) {
    ServerConfig config;
    config.port = SERVER_DEFAULT_PORT;
    snprintf(config.frontend_root, sizeof(config.frontend_root), "../frontend");

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
            config.port = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--frontend-root") == 0 && i + 1 < argc) {
            snprintf(config.frontend_root, sizeof(config.frontend_root), "%s", argv[++i]);
        } else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            print_usage(argv[0]);
            return 0;
        }
    }

    if (config.port <= 0 || config.port > 65535) {
        fprintf(stderr, "Port must be between 1 and 65535.\n");
        return 1;
    }

    return start_server(&config) == 0 ? 1 : 0;
}

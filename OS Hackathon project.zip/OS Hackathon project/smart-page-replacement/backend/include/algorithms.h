#ifndef ALGORITHMS_H
#define ALGORITHMS_H

#include <stddef.h>

#define MAX_REASON_CHARS 200

typedef enum {
    ALGO_FIFO = 0,
    ALGO_LRU = 1,
    ALGO_OPTIMAL = 2,
    ALGO_INVALID = -1
} AlgorithmType;

typedef struct {
    int step_number;
    int request_index;
    int requested_page;
    int hit;
    int page_fault;
    int replaced_page;
    int replaced_index;
    int frame_count;
    int *frames;
    char reason[MAX_REASON_CHARS];
} SimulationStep;

typedef struct {
    AlgorithmType algorithm;
    char algorithm_name[16];
    int total_requests;
    int page_hits;
    int page_faults;
    int evictions;
    int frame_count;
    double hit_rate;
    double fault_rate;
    SimulationStep *steps;
    int step_count;
} SimulationResult;

const char *algorithm_name_string(AlgorithmType algorithm);
int simulate_pages(const int *pages, int page_count, int frame_count, AlgorithmType algorithm, SimulationResult *result);
void free_simulation_result(SimulationResult *result);
int validate_algorithm_name(const char *value, AlgorithmType *algorithm, char *error, size_t error_size);

#endif

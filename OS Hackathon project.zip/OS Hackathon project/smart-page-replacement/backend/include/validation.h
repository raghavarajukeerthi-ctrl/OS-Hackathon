#ifndef VALIDATION_H
#define VALIDATION_H

#include <stddef.h>

int validate_sequence(const int *pages, int page_count, int frame_count, char *error, size_t error_size);
int parse_pages_array(const char *json, int **pages_out, int *page_count_out, char *error, size_t error_size);
int parse_json_int_field(const char *json, const char *field_name, int *value_out, char *error, size_t error_size);
int parse_json_string_field(const char *json, const char *field_name, char *value_out, size_t value_size, char *error, size_t error_size);

#endif

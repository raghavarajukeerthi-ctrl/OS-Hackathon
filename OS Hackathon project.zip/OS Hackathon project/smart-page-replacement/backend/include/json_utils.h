#ifndef JSON_UTILS_H
#define JSON_UTILS_H

#include <stddef.h>
#include "algorithms.h"

void json_escape_string(char *dst, size_t dst_size, const char *src);
int write_health_json(char *buffer, size_t buffer_size, int status_code, const char *version, long uptime_seconds);
int write_algorithm_list_json(char *buffer, size_t buffer_size, const char *version);
int write_example_json(char *buffer, size_t buffer_size, const char *version);
int write_simulation_json(char *buffer, size_t buffer_size, const SimulationResult *result, const char *version);
int write_compare_json(char *buffer, size_t buffer_size, const SimulationResult *results, int count, const char *version);

#endif

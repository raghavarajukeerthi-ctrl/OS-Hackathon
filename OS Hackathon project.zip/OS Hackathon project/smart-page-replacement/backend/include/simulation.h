#ifndef SIMULATION_H
#define SIMULATION_H

#include "algorithms.h"

int build_summary_result(const SimulationResult *result, char *buffer, size_t buffer_size);

#endif

#ifndef SERVER_H
#define SERVER_H

#define SERVER_DEFAULT_PORT 8080
#define SERVER_MAX_PATH 512

typedef struct {
    int port;
    char frontend_root[SERVER_MAX_PATH];
} ServerConfig;

int start_server(const ServerConfig *config);

#endif

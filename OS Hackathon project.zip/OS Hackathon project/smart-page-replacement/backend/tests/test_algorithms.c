#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "algorithms.h"
#include "validation.h"

static void test_fifo_standard(void) {
    const int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};
    SimulationResult result;
    assert(simulate_pages(pages, 13, 3, ALGO_FIFO, &result));
    assert(result.page_faults == 9 && result.page_hits == 4);
    free_simulation_result(&result);
}

static void test_lru_standard(void) {
    const int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};
    SimulationResult result;
    assert(simulate_pages(pages, 13, 3, ALGO_LRU, &result));
    assert(result.page_faults == 9 && result.page_hits == 4);
    free_simulation_result(&result);
}

static void test_optimal_standard(void) {
    const int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2};
    SimulationResult result;
    assert(simulate_pages(pages, 13, 3, ALGO_OPTIMAL, &result));
    assert(result.page_faults == 7 && result.page_hits == 6);
    free_simulation_result(&result);
}

static void test_repeated_pages(void) {
    const int pages[] = {1, 1, 1, 1, 1};
    SimulationResult result;
    assert(simulate_pages(pages, 5, 2, ALGO_FIFO, &result));
    assert(result.page_faults == 1 && result.page_hits == 4);
    free_simulation_result(&result);
}

static void test_one_frame(void) {
    const int pages[] = {1, 2, 3, 4, 1};
    SimulationResult result;
    assert(simulate_pages(pages, 5, 1, ALGO_LRU, &result));
    assert(result.page_faults == 5 && result.page_hits == 0);
    free_simulation_result(&result);
}

static void test_more_frames_than_unique_pages(void) {
    const int pages[] = {1, 2, 3};
    SimulationResult result;
    assert(simulate_pages(pages, 3, 10, ALGO_FIFO, &result));
    assert(result.page_faults == 3 && result.page_hits == 0);
    free_simulation_result(&result);
}

static void test_empty_sequence(void) {
    const int pages[] = {0};
    SimulationResult result;
    assert(simulate_pages(pages, 0, 3, ALGO_FIFO, &result));
    assert(result.page_faults == 0 && result.page_hits == 0);
    free_simulation_result(&result);
}

static void test_invalid_frame_count(void) {
    const int pages[] = {1, 2, 3};
    char error[128];
    assert(!validate_sequence(pages, 3, 0, error, sizeof(error)));
}

static void test_invalid_algorithm_name(void) {
    AlgorithmType algorithm = ALGO_INVALID;
    char error[128];
    assert(!validate_algorithm_name("Bogus", &algorithm, error, sizeof(error)));
}

static void test_parse_pages_json(void) {
    const char *json = "{\"pages\":[7,0,1,2,0],\"frames\":3,\"algorithm\":\"LRU\"}";
    int *pages = NULL;
    int page_count = 0;
    char error[128];
    assert(parse_pages_array(json, &pages, &page_count, error, sizeof(error)));
    assert(page_count == 5);
    assert(pages[0] == 7 && pages[4] == 0);
    free(pages);
}

static void test_belady_anomaly(void) {
    const int pages[] = {1, 2, 3, 4, 1, 2, 5};
    SimulationResult fifo_three;
    SimulationResult fifo_four;
    assert(simulate_pages(pages, 7, 3, ALGO_FIFO, &fifo_three));
    assert(simulate_pages(pages, 7, 4, ALGO_FIFO, &fifo_four));
    (void)fifo_three;
    (void)fifo_four;
    free_simulation_result(&fifo_three);
    free_simulation_result(&fifo_four);
}

int main(void) {
    test_fifo_standard();
    test_lru_standard();
    test_optimal_standard();
    test_repeated_pages();
    test_one_frame();
    test_more_frames_than_unique_pages();
    test_empty_sequence();
    test_invalid_frame_count();
    test_invalid_algorithm_name();
    test_parse_pages_json();
    test_belady_anomaly();
    printf("All algorithm tests passed.\n");
    return 0;
}

# Smart Page Replacement Simulator

A local OS project that simulates page replacement algorithms in C and exposes them through a lightweight JSON API and browser-based dashboard.

## Overview

This project demonstrates how common virtual memory page replacement policies behave under a reference string:

- FIFO
- LRU
- Optimal

The backend performs the actual simulation logic in C, while the frontend visualizes the memory state, hit/fault behavior, and comparisons across algorithms.

## Features

- Real page replacement simulation in C
- JSON API endpoints for health checks, algorithm metadata, example data, simulation, and comparison
- Browser dashboard with summary statistics and playback
- Step-by-step memory trace generation
- Algorithm comparison table and charts
- Responsive UI for local use
- Automated backend regression tests

## Project Structure

```text
smart-page-replacement/
├── backend/
│   ├── include/
│   ├── src/
│   ├── tests/
│   ├── build/
│   ├── Makefile
│   └── ...
├── frontend/
│   ├── css/
│   ├── js/
│   └── index.html
├── docs/
├── README.md
└── ...
```

## Prerequisites

You need a C compiler and make available in your environment.

On Windows, the project was validated using a MinGW toolchain from MSYS2:

```powershell
$env:Path = "C:\msys64\mingw64\bin;C:\msys64\usr\bin;$env:Path"
```

Then verify:

```powershell
gcc --version
make --version
```

## Quick Start

From the backend directory:

```powershell
cd backend
make all
make run
```

This starts the local server and serves the frontend at:

```text
http://localhost:8080
```

## Running Tests

```powershell
cd backend
make test
```

This builds and runs the regression suite for the page replacement logic.

## API Endpoints

The backend exposes the following local endpoints:

- `GET /api/health` — health check
- `GET /api/algorithms` — list available algorithms
- `GET /api/example` — example page sequence payload
- `POST /api/simulate` — run a single algorithm simulation
- `POST /api/compare` — compare FIFO, LRU, and Optimal on the same sequence

Example simulation request:

```json
{
  "frames": 3,
  "algorithm": "FIFO",
  "sequence": "1,2,3,4,1,2,5,1,2,3,4,5"
}
```

## Frontend

The frontend is a single-page dashboard that lets you:

- enter a page-reference sequence
- choose a frame count
- select an algorithm
- view summary statistics
- step through the simulation
- compare all three algorithms side by side

## Algorithms Implemented

### FIFO
Removes the page that entered memory first.

### LRU
Removes the least recently used page.

### Optimal
Removes the page that will not be used for the longest time in the future.

## Build Notes

The backend is written in C and is designed to keep the simulation logic real and deterministic rather than JavaScript-only. The Windows version uses the socket library required by the server (`-lws2_32` when building under MinGW/MSYS).

## Notes

- The app is intended for local, offline use.
- No external services are required for the simulator to run.
- The project is suitable for academic use as a demonstration of page replacement behavior in operating systems.

## License

This project is provided for educational and local demonstration use.

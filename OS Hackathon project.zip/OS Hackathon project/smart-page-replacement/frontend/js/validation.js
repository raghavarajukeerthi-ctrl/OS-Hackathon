function parseSequenceValue(rawValue) {
  if (!rawValue || !rawValue.trim()) {
    return { valid: false, error: 'Please enter a page-reference sequence.' };
  }

  const normalized = rawValue
    .trim()
    .replace(/\s+/g, '')
    .replace(/,$/, '');

  if (!normalized) {
    return { valid: false, error: 'The page-reference sequence cannot be empty.' };
  }

  const parts = normalized.split(',').filter((part) => part !== '');
  if (parts.length === 0) {
    return { valid: false, error: 'The sequence format is invalid.' };
  }

  const pages = [];
  for (const part of parts) {
    if (!/^-?\d+$/.test(part)) {
      return { valid: false, error: `Invalid page value '${part}'. Use integers only.` };
    }
    const value = Number(part);
    if (!Number.isInteger(value) || value < 0) {
      return { valid: false, error: `Page value '${part}' must be a non-negative integer.` };
    }
    pages.push(value);
  }

  return { valid: true, pages };
}

function validateSimulationInput(sequence, frames) {
  if (!sequence || sequence.trim() === '') {
    return 'Please enter a page-reference sequence.';
  }

  const parsed = parseSequenceValue(sequence);
  if (!parsed.valid) {
    return parsed.error;
  }

  if (!Number.isInteger(frames) || frames <= 0) {
    return 'Frame count must be a positive integer.';
  }

  if (frames > 256) {
    return 'Frame count must not exceed 256.';
  }

  if (parsed.pages.length > 10000) {
    return 'This sequence is too large for the simulator.';
  }

  return '';
}

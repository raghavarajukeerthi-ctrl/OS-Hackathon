class SimulatorController {
  constructor() {
    this.currentResult = null;
    this.currentStepIndex = 0;
    this.playTimer = null;
  }

  setResult(result) {
    this.currentResult = result;
    this.currentStepIndex = result && result.steps && result.steps.length ? 0 : 0;
    this.stopPlayback();
    updatePlaybackSummary(this.currentResult, this.currentStepIndex);
    this.updateSummaryCards();
  }

  updateSummaryCards() {
    if (!this.currentResult) {
      document.getElementById('total-requests').textContent = '0';
      document.getElementById('memory-frames').textContent = '0';
      document.getElementById('page-hits').textContent = '0';
      document.getElementById('page-faults').textContent = '0';
      document.getElementById('fault-rate').textContent = '0%';
      document.getElementById('selected-algorithm').textContent = 'FIFO';
      return;
    }

    const totalRequests = this.currentResult.total_requests ?? 0;
    const frames = this.currentResult.frames ?? 0;
    const hits = this.currentResult.hits ?? 0;
    const faults = this.currentResult.faults ?? 0;
    const faultRate = totalRequests > 0 ? (faults / totalRequests) * 100 : 0;

    document.getElementById('total-requests').textContent = String(totalRequests);
    document.getElementById('memory-frames').textContent = String(frames);
    document.getElementById('page-hits').textContent = String(hits);
    document.getElementById('page-faults').textContent = String(faults);
    document.getElementById('fault-rate').textContent = `${faultRate.toFixed(1)}%`;
    document.getElementById('selected-algorithm').textContent = this.currentResult.algorithm || 'FIFO';
  }

  nextStep() {
    if (!this.currentResult || !this.currentResult.steps || !this.currentResult.steps.length) {
      return;
    }

    if (this.currentStepIndex < this.currentResult.steps.length - 1) {
      this.currentStepIndex += 1;
      updatePlaybackSummary(this.currentResult, this.currentStepIndex);
    }
  }

  previousStep() {
    if (!this.currentResult || !this.currentResult.steps || !this.currentResult.steps.length) {
      return;
    }

    if (this.currentStepIndex > 0) {
      this.currentStepIndex -= 1;
      updatePlaybackSummary(this.currentResult, this.currentStepIndex);
    }
  }

  play() {
    if (!this.currentResult || !this.currentResult.steps || !this.currentResult.steps.length) {
      return;
    }

    this.stopPlayback();
    this.playTimer = window.setInterval(() => {
      if (this.currentStepIndex >= this.currentResult.steps.length - 1) {
        this.stopPlayback();
        return;
      }
      this.currentStepIndex += 1;
      updatePlaybackSummary(this.currentResult, this.currentStepIndex);
    }, 700);
  }

  stopPlayback() {
    if (this.playTimer) {
      window.clearInterval(this.playTimer);
      this.playTimer = null;
    }
  }

  resetPlayback() {
    this.currentStepIndex = 0;
    this.stopPlayback();
    if (this.currentResult) {
      updatePlaybackSummary(this.currentResult, this.currentStepIndex);
    }
  }
}

window.simulatorController = new SimulatorController();

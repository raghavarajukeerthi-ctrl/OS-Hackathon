function formatPercent(value) {
  if (value === null || value === undefined || Number.isNaN(value)) {
    return '0%';
  }
  return `${(value * 100).toFixed(2)}%`;
}

function fillComparisonTable(results) {
  const tbody = document.querySelector('#comparison-table tbody');
  if (!tbody) {
    return;
  }

  if (!results || !results.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">No comparison data available yet.</td></tr>';
    return;
  }

  tbody.innerHTML = results
    .map((result) => {
      const hitRate = result.total_requests > 0 ? result.hits / result.total_requests : 0;
      const faultRate = result.total_requests > 0 ? result.faults / result.total_requests : 0;
      return `
        <tr>
          <td>${result.algorithm}</td>
          <td>${result.total_requests}</td>
          <td>${result.hits}</td>
          <td>${result.faults}</td>
          <td>${formatPercent(hitRate)}</td>
          <td>${formatPercent(faultRate)}</td>
          <td>${result.evictions}</td>
        </tr>
      `;
    })
    .join('');
}

function renderCharts(results) {
  const labels = results.map((result) => result.algorithm);
  const faults = results.map((result) => result.faults);
  const hitRates = results.map((result) => result.total_requests > 0 ? result.hits / result.total_requests : 0);

  const faultCtx = document.getElementById('fault-chart');
  const rateCtx = document.getElementById('rate-chart');

  if (faultCtx && rateCtx) {
    if (window.faultChart) {
      window.faultChart.destroy();
    }
    if (window.rateChart) {
      window.rateChart.destroy();
    }

    window.faultChart = new Chart(faultCtx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Page faults',
          data: faults,
          backgroundColor: ['#ff7b54', '#64b5f6', '#66bb6a'],
          borderRadius: 8,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } },
      },
    });

    window.rateChart = new Chart(rateCtx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          label: 'Hit rate',
          data: hitRates.map((value) => Number(value.toFixed(4))),
          backgroundColor: ['#ff7b54', '#64b5f6', '#66bb6a'],
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom' } },
      },
    });
  }
}

function renderStepDetails(stepData) {
  const container = document.getElementById('step-details');
  if (!container) {
    return;
  }

  if (!stepData) {
    container.textContent = 'Run a simulation to see detailed frame behavior.';
    container.classList.add('empty-state');
    return;
  }

  container.classList.remove('empty-state');

  const frames = stepData.frames || [];
  const formattedFrames = frames.length
    ? frames.map((value) => (value === null || value === undefined ? '—' : value)).join(' | ')
    : 'No frames allocated';

  const page = stepData.page !== undefined ? stepData.page : 'N/A';
  const event = stepData.type || stepData.event || 'step';
  const status = stepData.status || 'Unknown';
  const reason = stepData.reason || 'No additional explanation.';

  container.innerHTML = `
    <div class="step-card">
      <div class="step-summary">
        <span class="tag">${event}</span>
        <span class="tag status-${status.toLowerCase()}">${status}</span>
      </div>
      <div class="step-line"><strong>Page requested:</strong> ${page}</div>
      <div class="step-line"><strong>Frames:</strong> ${formattedFrames}</div>
      <div class="step-line"><strong>Reason:</strong> ${reason}</div>
    </div>
  `;
}

function updatePlaybackSummary(result, currentIndex) {
  const totalStepLabel = document.getElementById('total-step-label');
  const currentStepLabel = document.getElementById('current-step-label');

  if (totalStepLabel) {
    totalStepLabel.textContent = result && result.steps ? result.steps.length : 0;
  }

  if (currentStepLabel) {
    currentStepLabel.textContent = result ? currentIndex : 0;
  }

  const stepData = result && result.steps && result.steps[currentIndex] ? result.steps[currentIndex] : null;
  renderStepDetails(stepData);
}

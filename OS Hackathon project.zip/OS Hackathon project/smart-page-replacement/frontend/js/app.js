document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('simulation-form');
  const sequenceInput = document.getElementById('sequence-input');
  const frameCountInput = document.getElementById('frame-count');
  const algorithmSelect = document.getElementById('algorithm-select');
  const statusMessage = document.getElementById('status-message');

  const setStatus = (message, kind = 'info') => {
    statusMessage.textContent = message;
    statusMessage.className = `status-message ${kind}`;
  };

  const loadExample = async () => {
    try {
      const example = await getExample();
      if (example && example.sequence) {
        sequenceInput.value = example.sequence;
        frameCountInput.value = example.frames || 3;
        const algorithm = example.algorithm || 'FIFO';
        algorithmSelect.value = algorithm;
        setStatus('Example loaded successfully.');
      }
    } catch (error) {
      setStatus('Could not load the example. Please try again.', 'error');
    }
  };

  const runSingleSimulation = async () => {
    const validationError = validateSimulationInput(sequenceInput.value, Number(frameCountInput.value));
    if (validationError) {
      setStatus(validationError, 'error');
      return;
    }

    const payload = {
      sequence: sequenceInput.value,
      frames: Number(frameCountInput.value),
      algorithm: algorithmSelect.value,
    };

    try {
      setStatus('Running simulation...', 'info');
      const result = await runSimulation(payload);
      if (result.error) {
        setStatus(result.error, 'error');
        return;
      }

      window.simulatorController.setResult(result);
      setStatus(`Simulation complete for ${result.algorithm}.`, 'success');
    } catch (error) {
      setStatus('The simulator could not complete the request.', 'error');
    }
  };

  const runComparison = async () => {
    const validationError = validateSimulationInput(sequenceInput.value, Number(frameCountInput.value));
    if (validationError) {
      setStatus(validationError, 'error');
      return;
    }

    const payload = {
      sequence: sequenceInput.value,
      frames: Number(frameCountInput.value),
    };

    try {
      setStatus('Comparing algorithms...', 'info');
      const result = await runComparison(payload);
      if (result.error) {
        setStatus(result.error, 'error');
        return;
      }

      fillComparisonTable(result.results || []);
      renderCharts(result.results || []);
      setStatus('Comparison ready.', 'success');

      if (result.results && result.results.length) {
        const preferred = result.results.find((entry) => entry.algorithm === algorithmSelect.value) || result.results[0];
        window.simulatorController.setResult(preferred);
      }
    } catch (error) {
      setStatus('The comparison request failed.', 'error');
    }
  };

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    runSingleSimulation();
  });

  document.getElementById('compare-all').addEventListener('click', runComparison);
  document.getElementById('reset-form').addEventListener('click', () => {
    sequenceInput.value = '';
    frameCountInput.value = 3;
    algorithmSelect.value = 'FIFO';
    window.simulatorController.setResult(null);
    setStatus('Form reset.');
    updatePlaybackSummary(null, 0);
  });

  document.getElementById('load-example').addEventListener('click', loadExample);
  document.getElementById('next-step').addEventListener('click', () => window.simulatorController.nextStep());
  document.getElementById('prev-step').addEventListener('click', () => window.simulatorController.previousStep());
  document.getElementById('play-toggle').addEventListener('click', () => window.simulatorController.play());
  document.getElementById('pause-toggle').addEventListener('click', () => window.simulatorController.stopPlayback());
  document.getElementById('reset-playback').addEventListener('click', () => window.simulatorController.resetPlayback());

  document.getElementById('theme-toggle').addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    const button = document.getElementById('theme-toggle');
    button.textContent = document.body.classList.contains('dark-mode') ? '☀️' : '🌙';
  });

  window.addEventListener('load', async () => {
    updatePlaybackSummary(null, 0);
    try {
      const health = await getHealth();
      if (health && health.status === 'ok') {
        setStatus('Connected to the simulator server.', 'success');
      } else {
        setStatus('Server responded but health is unknown.', 'info');
      }
    } catch (error) {
      setStatus('Backend server is not available. Start the local C server first.', 'error');
    }
    await loadExample();
  });
});

async function requestJson(url, options = {}) {
  const response = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });

  const contentType = response.headers.get('Content-Type') || '';
  const text = await response.text();
  if (!text) {
    return {};
  }

  if (contentType.includes('application/json')) {
    try {
      return JSON.parse(text);
    } catch (error) {
      throw new Error('API response was not valid JSON.');
    }
  }

  return { raw: text };
}

async function getHealth() {
  return requestJson('/api/health', { method: 'GET' });
}

async function getAlgorithms() {
  return requestJson('/api/algorithms', { method: 'GET' });
}

async function getExample() {
  return requestJson('/api/example', { method: 'GET' });
}

async function runSimulation(payload) {
  return requestJson('/api/simulate', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

async function runComparison(payload) {
  return requestJson('/api/compare', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}
